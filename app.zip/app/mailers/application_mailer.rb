class ApplicationMailer < ActionMailer::Base
  default from: "shmishra@tamu.edu"
  layout "mailer"
end
