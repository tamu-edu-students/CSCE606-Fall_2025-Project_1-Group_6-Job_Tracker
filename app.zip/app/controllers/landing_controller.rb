class LandingController < ApplicationController
  def index
    # Add any logic for your landing page here
  end
end
